//Example of enumerated type
#include <stdio.h>
enum week{ sunday, monday, tuesday, wednesday, thursday, friday, saturday};
int main(){
    enum week today;
    today=wednesday;
    printf("%d day",sunday);
    return 0;
   }
